var secret = {
    marvelAPI:{
        apiKey:"f15fc35ccad41a7125ba9eca17a7f792",
        hash:"b7a63e3d31a2cfb32857406aab493945"
    }
}